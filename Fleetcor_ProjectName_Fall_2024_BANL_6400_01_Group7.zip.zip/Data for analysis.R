library(randomForest)
library(glmnet)
library(forecast)
library(dplyr)
library(ggplot2)
library(cluster)
library(caret)
library(readr)

cross_sell <- read_excel("Cross-Sell Acct.xlsx")
non_cross_sell <- read_excel("Non Cross-Sell Acct Info.xlsx")
non_cross_sell_nsf <- read_excel("Non Cross-Sell NSF Payment.xlsx")
non_cross_sell_revenue <- read_excel("Non Cross-Sell Revenue.xlsx")
non_cross_sell_spend <- read_excel("Non Cross-Sell Spend.xlsx")
non_cross_sell_write_off <- read_excel("Non Cross-Sell Write-Off.xlsx")
non_cross_sell_aging <- read_excel("Non Cross-Sell Aging Data.xlsx")
non_cross_sell_dnb <- read_excel("Non Cross-Sell DNB Score.xlsx")
non_cross_sell_payment <- read_excel("Non Cross-Sell Payment.xlsx")
non_cross_sell_vantage <- read_excel("Non Cross-Sell Vantage Score.xlsx")


anyDuplicated(non_cross_sell_nsf$FAKE_ACCTCODE)
anyDuplicated(non_cross_sell_revenue$FAKE_ACCTCODE)
anyDuplicated(non_cross_sell_spend$FAKE_ACCTCODE)
anyDuplicated(non_cross_sell_write_off$FAKE_ACCTCODE)
anyDuplicated(non_cross_sell_aging$FAKE_ACCTCODE)
anyDuplicated(non_cross_sell_dnb$FAKE_ACCTCODE)
anyDuplicated(non_cross_sell_payment$FAKE_ACCTCODE)
anyDuplicated(non_cross_sell_vantage$FAKE_ACCTCODE)





# Remove duplicate rows based on FAKE_ACCTCODE
non_cross_sell_nsf <- non_cross_sell_nsf[!duplicated(non_cross_sell_nsf$FAKE_ACCTCODE), ]
non_cross_sell_revenue <- non_cross_sell_revenue[!duplicated(non_cross_sell_revenue$FAKE_ACCTCODE), ]
non_cross_sell_spend <- non_cross_sell_spend[!duplicated(non_cross_sell_spend$FAKE_ACCTCODE), ]
non_cross_sell_write_off <- non_cross_sell_write_off[!duplicated(non_cross_sell_write_off$FAKE_ACCTCODE), ]
non_cross_sell_aging <- non_cross_sell_aging[!duplicated(non_cross_sell_aging$FAKE_ACCTCODE), ]
non_cross_sell_dnb <- non_cross_sell_dnb[!duplicated(non_cross_sell_dnb$FAKE_ACCTCODE), ]
non_cross_sell_payment <- non_cross_sell_payment[!duplicated(non_cross_sell_payment$FAKE_ACCTCODE), ]
non_cross_sell_vantage <- non_cross_sell_vantage[!duplicated(non_cross_sell_vantage$FAKE_ACCTCODE), ]



library(dplyr)
# Merging datasets by the common column "FAKE_ACCTCODE"
merged_data <- non_cross_sell_nsf %>%
  left_join(non_cross_sell_revenue, by = "FAKE_ACCTCODE") %>%
  left_join(non_cross_sell_spend, by = "FAKE_ACCTCODE") %>%
  left_join(non_cross_sell_write_off, by = "FAKE_ACCTCODE") %>%
  left_join(non_cross_sell_aging, by = "FAKE_ACCTCODE") %>%
  left_join(non_cross_sell_dnb, by = "FAKE_ACCTCODE") %>%
  left_join(non_cross_sell_payment, by = "FAKE_ACCTCODE") %>%
  left_join(non_cross_sell_vantage, by = "FAKE_ACCTCODE")

View(merged_data)

# Impute missing values using the mean of each column (for numerical data only)
merged_data <- merged_data %>%
  mutate(across(where(is.numeric), ~ ifelse(is.na(.), mean(., na.rm = TRUE), .)))
View(merged_data)

# Removing rows with any missing values
merged_data <- na.omit(merged_data)
View(merged_data)

# Build a linear regression model with TOT_SPEND as the dependent variable
model_tot_spend <- lm(TOT_SPEND ~ CREDIT_LIMIT + CURRENT_BALANCE + 
                        DAYS_PAST_DUE + UNBILLED_BALANCE + PAYDEX + NSF_AMOUNT +
                        NSF_PMTS + NO_OF_PAYMENT + PAYMENT_AMOUNT + FUEL_SPEND +
                        VANTAGE_SCORE, data = merged_data)

# Summary of the model to check coefficients and significance levels
summary(model_tot_spend)


# Plotting TOT_SPEND vs DAYS_PAST_DUE with regression line
ggplot(merged_data, aes(x = DAYS_PAST_DUE, y = TOT_SPEND)) +
  geom_point() +
  geom_smooth(method = "lm", col = "blue") +
  labs(title = "Sensitivity of Total Spend to Days Past Due", x = "Days Past Due", y = "Total Spend")

# Simulate different values for DAYS_PAST_DUE and predict TOT_SPEND
new_data <- data.frame(
  DAYS_PAST_DUE = c(10, 30, 60),
  CREDIT_LIMIT = mean(merged_data$CREDIT_LIMIT, na.rm = TRUE),
  CURRENT_BALANCE = mean(merged_data$CURRENT_BALANCE, na.rm = TRUE),
  UNBILLED_BALANCE = mean(merged_data$UNBILLED_BALANCE, na.rm = TRUE),
  PAYDEX = mean(merged_data$PAYDEX, na.rm = TRUE),
  NSF_AMOUNT = mean(merged_data$NSF_AMOUNT, na.rm = TRUE),
  NSF_PMTS = mean(merged_data$NSF_PMTS, na.rm = TRUE),
  NO_OF_PAYMENT = mean(merged_data$NO_OF_PAYMENT, na.rm = TRUE),
  PAYMENT_AMOUNT = mean(merged_data$PAYMENT_AMOUNT, na.rm = TRUE),
  FUEL_SPEND = mean(merged_data$FUEL_SPEND, na.rm = TRUE),
  VANTAGE_SCORE = mean(merged_data$VANTAGE_SCORE, na.rm = TRUE)
)

predicted_tot_spend <- predict(model_tot_spend, newdata = new_data)
print(predicted_tot_spend)


# Line plot for DAYS_PAST_DUE vs TOT_SPEND
plt.figure(figsize=(10,6))
sns.lineplot(x='DAYS_PAST_DUE', y='TOT_SPEND', data=predicted_tot_spend, ci=None, color='blue')
plt.title("Trend: Days Past Due vs Total Spend")
plt.xlabel("Days Past Due")
plt.ylabel("Total Spend ($)")
plt.grid(True)
plt.show()

# Histogram for CURRENT_BALANCE
ggplot(merged_data, aes(x = DAYS_PAST_DUE, y = TOT_SPEND)) +
  geom_point() +
  geom_smooth(method = "lm", color = "blue") +
  labs(title = "Sensitivity of Total Spend to Days Past Due", 
       x = "Days Past Due", y = "Total Spend")


# Boxplot for CREDIT_LIMIT vs TOT_SPEND (categorized by quartiles)
merged_data <- merged_data %>%
  mutate(CREDIT_LIMIT_Category = cut(CREDIT_LIMIT, breaks = quantile(CREDIT_LIMIT, probs = 0:4/4, na.rm = TRUE), 
                                     labels = c("Low", "Medium", "High", "Very High"), include.lowest = TRUE))
ggplot(merged_data, aes(x = CREDIT_LIMIT_Category, y = TOT_SPEND)) +
  geom_boxplot() +
  labs(title = "Credit Limit Categories vs Total Spend", 
       x = "Credit Limit Category", y = "Total Spend")


# Heatmap for correlation between PAYMENT_AMOUNT, FUEL_SPEND, and TOT_SPEND
correlation_data = df[['PAYMENT_AMOUNT', 'FUEL_SPEND', 'TOT_SPEND']].corr()
plt.figure(figsize=(8,6))
sns.heatmap(correlation_data, annot=True, cmap='coolwarm', fmt=".2f")
plt.title("Correlation Heatmap: Payment, Fuel Spend, and Total Spend")
plt.show()